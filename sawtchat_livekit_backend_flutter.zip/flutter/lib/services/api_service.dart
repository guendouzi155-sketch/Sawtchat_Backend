import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  // Android emulator: 10.0.2.2 points to your computer.
  // Real phones: replace with your computer's LAN IP during local testing.
  final String baseUrl = 'http://10.0.2.2:3000';

  Future<({String token, String url})> getToken({
    required String identity,
    required String room,
  }) async {
    final response = await http.post(
      Uri.parse('$baseUrl/token'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'identity': identity, 'room': room}),
    );

    if (response.statusCode != 200) {
      throw Exception('Token server error: ${response.body}');
    }

    final data = jsonDecode(response.body) as Map<String, dynamic>;
    return (token: data['token'] as String, url: data['url'] as String);
  }
}