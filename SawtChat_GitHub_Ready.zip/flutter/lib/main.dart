import 'package:flutter/material.dart';
import 'services/api_service.dart';
import 'screens/home_screen.dart';

void main() => runApp(const SawtChatApp());

class SawtChatApp extends StatelessWidget {
  const SawtChatApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SawtChat',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.deepPurple),
      home: Directionality(
        textDirection: TextDirection.rtl,
        child: HomeScreen(api: ApiService()),
      ),
    );
  }
}