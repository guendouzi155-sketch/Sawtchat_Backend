import 'package:flutter/material.dart';
import 'package:livekit_client/livekit_client.dart';
import '../services/api_service.dart';

class RoomScreen extends StatefulWidget {
  final ApiService api;
  final String roomName;
  const RoomScreen({super.key, required this.api, required this.roomName});

  @override
  State<RoomScreen> createState() => _RoomScreenState();
}

class _RoomScreenState extends State<RoomScreen> {
  Room? _room;
  bool _micEnabled = false;
  bool _connecting = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _connect();
  }

  Future<void> _connect() async {
    try {
      final identity = 'user_${DateTime.now().millisecondsSinceEpoch}';
      final result = await widget.api.getToken(
        identity: identity,
        room: widget.roomName,
      );

      final room = Room();
      await room.connect(result.url, result.token);
      await room.localParticipant?.setMicrophoneEnabled(false);

      if (!mounted) return;
      setState(() {
        _room = room;
        _connecting = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _connecting = false;
        _error = e.toString();
      });
    }
  }

  Future<void> _toggleMic() async {
    final next = !_micEnabled;
    await _room?.localParticipant?.setMicrophoneEnabled(next);
    if (mounted) setState(() => _micEnabled = next);
  }

  @override
  void dispose() {
    _room?.disconnect();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: Text(widget.roomName)),
        body: _connecting
            ? const Center(child: CircularProgressIndicator())
            : _error != null
                ? Center(child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Text('تعذر الاتصال:\\n$_error'),
                  ))
                : Column(
                    children: [
                      const SizedBox(height: 30),
                      const Icon(Icons.graphic_eq, size: 70),
                      const SizedBox(height: 10),
                      const Text('متصل بالغرفة',
                        style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                      const Spacer(),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          FloatingActionButton(
                            heroTag: 'mic',
                            onPressed: _toggleMic,
                            child: Icon(_micEnabled ? Icons.mic : Icons.mic_off),
                          ),
                          FloatingActionButton(
                            heroTag: 'leave',
                            onPressed: () => Navigator.pop(context),
                            child: const Icon(Icons.call_end),
                          ),
                        ],
                      ),
                      const SizedBox(height: 30),
                    ],
                  ),
      ),
    );
  }
}