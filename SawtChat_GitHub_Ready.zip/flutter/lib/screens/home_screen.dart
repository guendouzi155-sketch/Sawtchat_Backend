import 'package:flutter/material.dart';
import '../services/api_service.dart';
import 'room_screen.dart';

class HomeScreen extends StatelessWidget {
  final ApiService api;
  const HomeScreen({super.key, required this.api});

  @override
  Widget build(BuildContext context) {
    final rooms = ['دردشة المساء', 'الرياضة وكرة القدم', 'تعلم وتطوير الذات'];
    return Scaffold(
      appBar: AppBar(title: const Text('SawtChat'), centerTitle: true),
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text('الغرف المباشرة',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            ...rooms.map((name) => Card(
              child: ListTile(
                leading: const CircleAvatar(child: Icon(Icons.mic)),
                title: Text(name),
                subtitle: const Text('غرفة صوتية مباشرة'),
                trailing: const Icon(Icons.chevron_left),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => RoomScreen(api: api, roomName: name),
                  ),
                ),
              ),
            )),
          ],
        ),
      ),
    );
  }
}